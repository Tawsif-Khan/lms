<?php
mysql_select_db('lms',mysql_connect('localhost','root',''));//or die(mysql_error());
?>