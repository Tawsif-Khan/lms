<?php 
include('session.php');
include('header.php'); ?>
<?php  ?>
<?php include('navbar_dashboard.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span12">		
                       
				<?php include('slider.php'); ?>
				
				
			</div>
                            <div class="offset1">
                                <?php include('thumbnail.php'); ?>
                            </div>
			</div>
		</div>
    </div>
<?php include('../footer.php') ?>